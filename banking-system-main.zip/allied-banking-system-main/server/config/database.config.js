module.exports = {
	url: "mongodb+srv://database_admin:database_password@basicbankingsystem.yr3hj.mongodb.net/basic-banking-system?retryWrites=true&w=majority"
};
